import django_filters
from django import forms
from .models import Post, Author

class PostsFilter(django_filters.FilterSet):
    date = django_filters.DateTimeFilter(field_name='data_add', lookup_expr='gte', label='Дата публикации (после)', widget=forms.DateTimeInput(attrs={'type': 'date'}))
    title = django_filters.CharFilter(field_name='post_title', lookup_expr='icontains', label='Заголовок')
    author = django_filters.ModelChoiceFilter(field_name='post_aut', queryset=Author.objects.all(), label='Автор', widget=forms.Select)
    
    class Meta:
        model = Post
        fields = ['date', 'title', 'author']