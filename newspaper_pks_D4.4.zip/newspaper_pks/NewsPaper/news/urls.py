from django.urls import path
from .views import PostsList, PostDetail, PostsSearch, PostAdd, PostEdit, PostDelete

urlpatterns = [
    path('', PostsList.as_view()),
    path('<int:pk>', PostDetail.as_view()),
    path('search/', PostsSearch.as_view()),
    path('add/', PostAdd.as_view()),
    path('<int:pk>/edit/', PostEdit.as_view(), name='post_edit'),
    path('<int:pk>/delete/', PostDelete.as_view(), name='post_delete'),
]
