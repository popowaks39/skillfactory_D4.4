from django.shortcuts import render
from django.views import View
from django.views.generic import ListView, DetailView, CreateView, UpdateView, DeleteView
from django.core.paginator import Paginator
from django.urls import reverse_lazy
from .models import Post, Author
from .filters import PostsFilter
from .forms import PostForm

class PostsList(ListView):
    model = Post
    template_name = 'posts.html'
    context_object_name = 'posts'
    ordering = ['-data_add']
    paginate_by = 10
    
class PostDetail(DetailView):
    model = Post
    template_name = 'post.html'
    context_object_name = 'post'
    
class PostsSearch(ListView):
    model = Post
    template_name = 'search.html'
    context_object_name = 'search_posts'
    
    def get_queryset(self):
        filter_form = PostsFilter(self.request.GET, queryset=super().get_queryset())
        search_posts = filter_form.qs

        selected_date = self.request.GET.get('date')
        selected_time = self.request.GET.get('time')

        if selected_date and selected_time:
            datetime_str = f'{selected_date} {selected_time}'
            selected_datetime = datetime.strptime(datetime_str, '%Y-%m-%d %H:%M')
            search_posts = search_posts.filter(dateCreation__gte=selected_datetime)
            
        selected_author = self.request.GET.get('post_aut')

        return search_posts
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        filter_form = PostsFilter(self.request.GET, queryset=self.get_queryset())
        author = Author.objects.all()
        selected_author = self.request.GET.get('post_aut')
        context['filter_form'] = filter_form
        context['author'] = author
        context['selected_author'] = selected_author
        return context
        
class PostAdd(CreateView):
    model = Post
    template_name = 'post_add.html'
    form_class = PostForm
       
class PostEdit(UpdateView):
    template_name = 'edit.html'
    form_class = PostForm
    
    def get_object(self, **kwargs):
       id = self.kwargs.get('pk')
       return Post.objects.get(pk=id)

class PostDelete(DeleteView):
    template_name = 'delete.html'
    queryset = Post.objects.all()
    success_url = reverse_lazy('news')