from django import forms
from django.forms import ModelForm
from .models import Post, Category

class PostForm(ModelForm):
    class Meta:
        model = Post
        category = forms.ModelMultipleChoiceField(queryset=Category.objects.all(), label='Категория')
        fields = ['post_aut', 'post_type', 'category', 'post_title', 'post_text']
        labels = {
            'post_aut': 'Автор',
            'post_type': 'Тип поста',
            'category': 'Категория',
            'post_title': 'Заголовок',
            'post_text': 'Текст',
        }
        widgets = {
            'post_aut': forms.TextInput(attrs={
                'class': 'form-control',
         }),
            'post_type': forms.Select(attrs={
                'class': 'form-control',
         }),
            'category': forms.Select(attrs={
                'class': 'form-control',
         }),
            'post_title': forms.TextInput(attrs={
                'class': 'form-control',
         }),
            'post_text': forms.Textarea(attrs={
           'class': 'form-control',
         }),
        }